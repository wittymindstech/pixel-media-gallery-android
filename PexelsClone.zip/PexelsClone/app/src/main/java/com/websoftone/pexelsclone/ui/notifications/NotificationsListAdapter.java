package com.websoftone.pexelsclone.ui.notifications;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.websoftone.pexelsclone.R;

import java.util.ArrayList;

public class NotificationsListAdapter extends RecyclerView.Adapter {
    ArrayList notificationNames;
    ArrayList notificationIcons;
    Context context;
    public NotificationsListAdapter(Context context, ArrayList notificationNames, ArrayList notificationIcons) {
        this.context = context;
        this.notificationNames = notificationNames;
        this.notificationIcons = notificationIcons;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.notification_list_design, parent, false);
        // set the view's size, margins, paddings and layout parameters
        MyViewHolder vh = new MyViewHolder(v); // pass the view to View Holder
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
//        holder.mlisttext.setText(notificationNames.get(position));
//        holder.listicon.setImageResource(notificationIcons.get(position));
//        holder.itemView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                //Toast.makeText(context, notificationNames.get(position), Toast.LENGTH_SHORT).show();
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return notificationNames.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        // init the item view's
        TextView listtext;
        ImageView listicon;
        public MyViewHolder(View itemView) {
            super(itemView);
            // get the reference of item view's
            listtext = (TextView) itemView.findViewById(R.id.text_list);
            listicon = (ImageView) itemView.findViewById(R.id.icon);
        }
    }
}

